//
// Created by Dylan Meadows on 2020-03-10.
//

#ifndef EONTIMER_FONTHELPER_H
#define EONTIMER_FONTHELPER_H

#include <QWidget>

namespace gui::util::font {
    void setFontSize(QWidget *widget, int fontSize);
}

#endif  // EONTIMER_FONTHELPER_H
