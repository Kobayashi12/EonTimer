#!/bin/bash

python3 -m qtsass -o resources/styles resources/styles
