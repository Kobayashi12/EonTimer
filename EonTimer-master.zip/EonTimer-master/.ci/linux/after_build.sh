#!/bin/bash

zip -r EonTimer-$OS.zip EonTimer
sha256sum EonTimer-$OS.zip > EonTimer-$OS.zip.sha256
