#!/bin/bash

make -j $(nproc)
