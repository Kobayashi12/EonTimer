#!/bin/bash

brew update
brew install qt5 sfml
brew link --force qt5
