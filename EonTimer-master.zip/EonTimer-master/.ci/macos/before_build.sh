#!/bin/bash

pip3 install qtsass
qtsass -o resources/styles resources/styles
